@extends('layouts.app-with-sidebar')

@section('content')
<section class="content-header">
   <h1>
     Owner List
     <small>Control panel</small>
   </h1>
 </section>

 <!-- Main content -->
 <section class="content">
   <div class="row">


      </div>
      <!-- /.row -->
 </section>
@endsection
