
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/dataTables.bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.slimscroll.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/fastclick.js')); ?>"></script>
<script src="<?php echo e(asset('js/adminlte.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.validate.min.js')); ?>"></script>

<script src="<?php echo e(asset('js/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap-datepicker.js')); ?>"></script>

<style>
.error{
  color:red;
}
</style>
